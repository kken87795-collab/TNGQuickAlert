package com.example.tngquickalert

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (22 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply {
            text = "TNG Quick Alert"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Aplikasi ini mengesan pautan Money Packet TNG yang muncul dalam notifikasi Facebook, kemudian memberi notifikasi khas untuk dibuka. Ia tidak menekan Claim secara automatik."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        val notifButton = Button(this).apply {
            text = "1. Benarkan notifikasi aplikasi"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
                } else {
                    openNotificationAccess()
                }
            }
        }
        val accessButton = Button(this).apply {
            text = "2. Hidupkan Notification Access"
            setOnClickListener { openNotificationAccess() }
        }
        val status = TextView(this).apply {
            text = "Pastikan notifikasi Facebook untuk group tersebut dihidupkan. Jika Facebook tidak memaparkan pautan penuh dalam notifikasi, aplikasi ini tidak dapat mengesannya."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, 0)
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(notifButton)
        layout.addView(accessButton)
        layout.addView(status)
        setContentView(layout)
    }

    private fun openNotificationAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }
}
